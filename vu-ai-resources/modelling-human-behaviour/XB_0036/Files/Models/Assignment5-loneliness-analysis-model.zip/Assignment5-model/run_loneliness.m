clear all
close all
model = l2('loneliness-l2');
model.simulate(10, "false");
model.plot()
model.reset()
model.simulate(10, "true");
model.plot()

