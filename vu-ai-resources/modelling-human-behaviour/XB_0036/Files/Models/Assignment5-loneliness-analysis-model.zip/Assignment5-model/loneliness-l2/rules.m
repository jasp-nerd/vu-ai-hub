function [ fncs ] = rules()
    % DO NOT EDIT
    fncs = l2.getRules();
    for i=1:length(fncs)
        fncs{i} = str2func(fncs{i});
    end
end

%ADD RULES BELOW

% observe the performance
function result = observe_performance(trace, params, t)
    result = {};
    for observation = l2.getall(trace, t, 'performance', {NaN})
        result = {t, 'observed', observation};
    end
end

% belief performance
function result = belief_performance(trace, params, t)
    result = {};
    for observation = l2.getall(trace, t, 'observed', {NaN})
        if strcmp(observation.arg{1}.arg{1}, 'low')      
            result = {t+1, 'belief', observation.arg{1}};
        elseif strcmp(observation.arg{1}.arg{1}, 'high')      
            result = {t+1, 'belief', observation.arg{1}};
        end
    end
end

% observe the cardiovascular disease
function result = observe_cardiovascular(trace, params, t)
    result = {};
    for observation = l2.getall(trace, t, 'cardiovascular_diseases', {NaN})
        result = {t, 'observed', observation};
    end
end


% belief cardiovascular disease
function result = belief_cardiovascular(trace, params, t)
    result = {};
    for observation = l2.getall(trace, t, 'observed', {NaN})
        if observation.arg{1}.arg{1} == 1      
            result = {t+1, 'belief', observation.arg{1}};
        elseif observation.arg{1}.arg{1} == 0      
            result = {t+1, 'belief', observation.arg{1}};
        end
    end
end

% belief feeling of loneliness
function result = belief_loneliness(trace, params, t)
    result = {};
   
    for belief = l2.getall(trace, t, 'belief', {NaN})
        x = 0
         if belief.arg{1}.arg{1} == 1 
             if strcmp(belief.arg{1}.arg{1}, 'low')
                x = 1;
             end
         end
         
         if x == 1
            result = {t+1, 'belief', predicate('feeling_of_loneliness', true)};
         end
    end
end


%assessment 
function result = assessment_loneliness(trace, params, t)
    result = {};
   
    for belief = l2.getall(trace, t, 'belief', {NaN})
        desire = l2.getall(trace, t, 'desire', {NaN})
        disp(belief.arg{1})
        if (desire.arg{1}.arg{1}) == 0 & belief.arg{1}.arg{1} == 1;
            result = {t, 'assessment', predicate('feeling_of_loneliness', true)};
        else
            result = {t, 'assessment', predicate('feeling_of_loneliness', false)};

        end
            
    end
end
