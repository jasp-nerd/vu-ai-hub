""" rules.py
    States the rules and contains an ecute allexecution function that can ex the rules
    """

from state import Predicate
#######################################


#######################################
# create any functions here


###############################
# any functions that actually need to be executed in the simulation must be put in this list
rules = []
