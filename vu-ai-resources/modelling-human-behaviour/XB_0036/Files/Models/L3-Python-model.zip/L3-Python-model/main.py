""" main.py
    Everything except the State and StateMachine, mainly for trying (can be deleted later)
    """
from state_machine import StateMachine
import rules


# MAX_T =
# scenario =
#
# StateMachine = StateMachine(scenario, MAX_T, rules.rules)
# StateMachine.run()
#
# StateMachine.run_visualization()