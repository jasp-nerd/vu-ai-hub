""" visualization.py
     for visualization
    """
from matplotlib import lines
from numpy import arange

import matplotlib.pyplot as plt

from state_machine import StateMachine
import rules


def make_visualization_dic(state_machine):
    visualization_dic = {}
    for state in state_machine.states:
        t = state.t
        predicates = state.predicates
        for predicate_name in predicates.keys():
            predicate = predicates[predicate_name]
            for predicate_values in predicate:
                agent = tuple(predicate_values.agents) if len(predicate_values.agents) > 1 else predicate_values.agents[
                    0]
                value = predicate_values.value
                visualization_dic = add_predicate_visualization(agent, value, predicate_name, visualization_dic, t)
    return visualization_dic


def add_predicate_visualization(agent, value, predicate_name, visual_dic, t):
    if predicate_name in visual_dic:
        if agent in visual_dic[predicate_name]:
            visual_dic[predicate_name][agent].append((t, value))
        else:
            visual_dic[predicate_name][agent] = [(t, value)]
    else:
        visual_dic[predicate_name] = {}
        visual_dic[predicate_name][agent] = [(t, value)]
    return visual_dic


def check_completeness(visual_dic):
    for predicate_name in visual_dic.keys():
        predicate = visual_dic[predicate_name]
        for agent in predicate.keys():
            for i in range(0, 50):
                t1 = i + 1
                t2 = visual_dic[predicate_name][agent][i][0]
                # print((i + 1, visual_dic[predicate_name][agent][i][0]))
                if t1 != t2:
                    visual_dic[predicate_name][agent].insert(i, (t1, None))
    return visual_dic


def create_lineplot(viz_dic, predicate_name, agent):
    data = viz_dic[predicate_name][agent]
    data = [d[1] for d in data]
    data.insert(0, 0)
    fig, ax = plt.subplots()
    ax.plot(data, linewidth=2.0)
    ax.set_xlabel("Time Step")
    ax.set_ylabel("%s (%s)" % (predicate_name, agent), rotation='horizontal', ha='right')
    plt.margins(0)
    plt.tight_layout()
    plt.show()


def create_matgraph(viz_dic, predicate_to_plot, timesteps):
    """predicate to plot is Input has to be list of tuples with predicate name, agent, value to be verified
    i.e. [("has_emotion_state",'arnie', 'sad'), ("has_emotion_state",'arnie', 'indifferent')],
     maximum amount of timesteps to be inserted"""
    data = []
    for i in predicate_to_plot:
        list = [8]
        x = viz_dic[i[0]][i[1]]
        print(x)
        for j in x[:timesteps + 1]:
            if j[1] is None:
                list.append(8)
            elif j[1] == i[2]:
                list.append(1)
            else:
                list.append(0)
        data.append(list)
    d = [x for x in range(timesteps + 1)]
    plt.matshow(data, cmap="Pastel1", fignum=1, aspect='auto')  # can there be two colors set?
    plt.xlabel("Time Steps", labelpad=5)
    names = []
    for i in predicate_to_plot:
        names.append("%s\n(%s,%s)" % (i[0], i[1], str(i[2])))
    plt.yticks(arange(len(predicate_to_plot)), names)
    plt.xticks(arange(-0.5, timesteps, step=1), ha="right", labels=d)
    for i in range(len(predicate_to_plot)):
        plt.axhline(i + 0.5, color='k')
    plt.grid(axis='x', color='k')
    plt.show()




def run_visualization(StateMachine):
    visualization_dic = make_visualization_dic(StateMachine)
    check_completeness(visualization_dic)
    create_lineplot(visualization_dic, "has_channel_strength", ('bernie', 'arnie'))
    create_matgraph(visualization_dic,
                [("has_emotion_state", 'arnie', 'happy'), ("has_emotion_state", 'arnie', 'indifferent'),
                 ("has_emotion_state", 'arnie', 'angry'), ("has_emotion_state", 'arnie', 'sad')
               ], 20)
