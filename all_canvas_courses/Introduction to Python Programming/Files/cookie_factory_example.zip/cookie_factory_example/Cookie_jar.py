from Cookie import Cookie

class Cookie_Jar:

      def __init__(self, capacity_n):
            if capacity_n < 0:
                  raise ValueError("The capacity cannot be negative")
            self.capacity = capacity_n
            self.cookies = []

      def deposit_cookie(self, cookie: Cookie):
            if self.get_number_cookies() < self.capacity:
                  self.cookies.append(cookie)
            else:
                  raise ValueError("This jar is full.")
            
      def withdraw_cookie(self):
            if len(self.get_number_cookies()) == 0:
                  raise ValueError("There are no cookies left in this jar")
            self.cookies.remove()
            
      def get_capacity(self):
            return self.capacity
      
      def get_number_cookies(self):
            return len(self.cookies)
      
      def __str__(self):
            return f"This cookie jar contains {len(self.cookies)} cookies out of {self.capacity}"

