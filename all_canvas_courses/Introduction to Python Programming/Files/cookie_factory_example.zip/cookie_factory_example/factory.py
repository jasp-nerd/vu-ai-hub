import csv
from typing import List
from Cookie_jar import Cookie_Jar
from Cookie import Cookie, Stroopwaffel, Macaroon

class Cookie_Factory:

      def __init__(self) -> None:
            self.cookie_jars = []

      def add_cookie_jars(self, jars_p) -> None:
            self.cookie_jars += jars_p

def read_file(file_path:str) -> List[Cookie_Jar]:
      """
      This function reads a file given the path.
      :param file_path path to the file
      :returns the content of the file received as parameter.
      """
      with open(file_path, 'r') as file:
            dict_file = csv.DictReader(file)
            cookie_jars = []
            
            # Iterate over all the rows
            # Create a list of cookies
            # Make a jar per row

            for row in dict_file:
                  number_cookies = int(row['cookies'])
                  type_cookie = int(row['type'])
                  price = row['price']
                  ingredients = row['ingredients']
                  allergens = row['allergens']
                  capacity = int(row['capacity'])
                  
                  cookie_jar = Cookie_Jar(capacity)

                  
                  if type_cookie == 1:
                        radius = row['radius']
                        for x in range(number_cookies):
                              stroop = Stroopwaffel(price, [ingredients], [allergens], radius)
                              cookie_jar.deposit_cookie(stroop)
                  elif type_cookie == 2:
                        color = row['color']
                        radius = row['radius']
                        for x in range(number_cookies):
                              mac = Macaroon(price, [ingredients], [allergens], color, radius)
                              cookie_jar.deposit_cookie(mac)
                  else:
                        raise ValueError("Unrecognized type of cookie")
                  
                  cookie_jars.append(cookie_jar)
            return cookie_jars
                  


def main():
      factory = Cookie_Factory()
      cookie_jars = read_file("../data.csv")
      factory.add_cookie_jars(cookie_jars)
      for jar in factory.cookie_jars:
            for cookie in jar.cookies:
                  if isinstance(cookie, Stroopwaffel):
                        print(cookie)
                  
      

      

if __name__ == "__main__":
      main()