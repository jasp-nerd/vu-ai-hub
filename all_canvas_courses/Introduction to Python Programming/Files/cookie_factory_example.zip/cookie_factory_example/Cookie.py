from typing import List

class Cookie:

      def __init__(self, price_p:float, ingredients_p: List[str], allergens_p: List[str]):
            self.price = price_p
            self.ingredients = ingredients_p
            self.allergens = allergens_p

      def __str__(self) -> str:
            return f"- The cookie contain the following ingredients: {self.ingredients} and allergens: {self.allergens}.\nThe price of each cookie is {self.price} euro."
            
class Round_Cookie(Cookie):
      """ This class represents a rounded cookie.
      """
      def __init__(self, price_p, ingredients_p, allergens_p, radius_p: float):
            super().__init__(price_p, ingredients_p, allergens_p)
            self.radius = radius_p

      def get_radius(self) -> float:
            return self.radius * 2


class Macaroon(Round_Cookie):
      """
      """

      def __init__(self, price_p: float, ingredients_p: List[str], allergens_p: List[str], color_p: str, radius_p: float):
            super().__init__(price_p, ingredients_p, allergens_p, radius_p)
            self.color = color_p

      def __str__(self):
            return f"- This Macaroon contains {self.ingredients} and allergens {self.allergens}.\nIt costs {self.price} euro."


class Stroopwaffel(Round_Cookie):

      def __init__(self, price_p: float, ingredients_p: List[str], allergens_p: List[str],radius_p: float):
            super().__init__(price_p, ingredients_p, allergens_p, radius_p)
            self.toppings = []
      
      def __str__(self):
            if len(self.toppings) == 0:
                  return f"- This stroopwaffel has a radius of {self.radius}cm and costs {self.price} euro."
            else:
                  return f"- This stroopwaffel has the following toppings: {self.toppings} a radius of {self.radius}cm and costs {self.price}."

      def add_toppings(self, topping: str) -> None:
            self.toppings.append(topping)

# cookie_1 = Cookie(5.3, ["flour", "sugar", "butter", "cinamon"], ["milk"])
# print(cookie_1)

# blue_macaroon = Macaroon(4, [], [], "blue", 2.0)
# print(blue_macaroon)

# plain_stroopwaffel = Stroopwaffel(2, ['cinamon', 'flour', 'caramel'], ['milk'], 3.4)
# print(plain_stroopwaffel)
# choco_stroopwaffel = Stroopwaffel(2, ['cinamon', 'flour', 'caramel'], ['milk'], 3.4)
# choco_stroopwaffel.add_toppings("chocolate")
# print(choco_stroopwaffel)