# XB_0082 - Assignment 3 (2024-2025)

This assignment aims to test your knowledge of classes and to inspire your logical creativity.

-----
* **Contributor name**: /replace by your full name/
* **VUnet ID**: /replace by your VUnet ID number/
  
**Date**: /replace by date of first modification/

-----

## Introduction

With a continuous increase in self-publishing, in 2019, an average of 2,700 books was published every day. Based simply on numbers, the competition for becoming a bestseller is fierce. 

Imagine you are working at a bookstore, and you have to decide which books you want in your store. There are just too many books being published for you to keep on top as it is. And you don’t just want any books on your shelves, you want the bestsellers, the books with great reviews and high ratings. To help you get through all the data you have decided to develop a system that analyzes the data for you.

To do this you will use a dataset containing Amazon's Top 50 bestselling books from 2009 to 2019. You'll want to to analyze the dataset and create an accessible way of getting insight out of it. Like what books managed to be bestsellers in multiple years, what was the average rating per year, and the average number of reviews.


### The Amazon Bestsellers Dataset

The dataset consists of 50 Amazon Bestsellers for every year from 2009 to 2019, with a total of 550 books. You can find all the information on [Kaggle](https://www.kaggle.com), a famous website containing many datasets, challenging tasks, and tons of inspiration from other coders. For more information visit [this link](https://www.kaggle.com/sootersaalu/amazon-top-50-bestselling-books-2009-2019).

Please note that this assignment contains the `bestsellers with categories.csv` file, but it has been renamed as `books.csv`. It is located in the data folder. Check out the file itself or the website to find out what the data looks like! The dataset is stored as a CSV file, whose values are separated by commas. The first line of the CSV file contains the following headers:

| Column | Description | 
|:-------|:------------|
| `Name` | Name of the Book |
| `Author` | The author of the Book |
| `User rating` | Amazon User Rating |
| `Reviews` | Number of written reviews on amazon |
| `Price` | The price of the book (as of 13/10/2020) | 
| `Year` | The Year(s) it ranked on the bestseller |
| `Genre` | Whether fiction or non-fiction |
	

-----

## Grading

This assignment consists of 5 tasks. Each task accounts for a different percentage of the grade. You can check the correct development of each task using the provided unit tests (`tests/*`).

Make sure all classes, methods and functions have type hints and a docstring that describes their purpose. You must follow all coding conventions defined in the coding-style-guide document available via Canvas under files>Guides and Tutorials. Otherwise, points will be deducted from your grade.

-----

## Testing

Implementing every single task in this assignment is necessary for the code in main to run. To help you verify your work intermediately we have implemented some tests. See `pytest.md` for instructions on how to use these tests.

_Note:_ Passing all unit tests does not guarantee that your assignment is perfect. However, failing tests means that your assignment contains errors, such as incomplete tasks or wrong implementations.

-----

## Tasks
To start with the assignment, fill in the information related to the contributors' name, ID, and date, displayed at the beginning of this document:

```python
* Contributor: ...
* VUnet ID: ...
```

To complete the program you will need to complete five tasks. With each task building on the previously completed ones. After completing all five tasks you will have a system ready for extracting all recommended books based on your search query. 

Each task must be developed within the `books_types.py` file in the books folder.


### Task 1: Create Amazon and Book Classes (15%)
Your first step is to design the foundation of your book analysation system. In your store you are selling objects, namely books! To be able to create a digital library of the books you can luckily create objects in python as well through classes. 
To start your program to analyse the Amazon book data for you, you will first define two classes on which you can build the rest of your system.


- Create the `Book` class, which contains the `title` (string), `author` (string), `rating` (float), `reviews` (integer), `price` (float), `years` (list of integers), and `genre` (string) attributes. Don't forget to create its constructor,`__init__()`, with the corresponding parameters in the given order.
- Define the `__str__()` method in the `Book` class. The method should return the title of the book.

- Create the `Amazon` class, which represents the list of bestsellers and only contains the attribute `bestsellers` (list of Books). Don't forget to create its constructor with the corresponding parameter.


### Task 2: Create FictionBook and NonFictionBook Classes (20%)
The books readers are looking for will often fall into one of two categories, namely fiction or non-fiction. To better serve your customers, you decide to refine your system to clearly classify books into one of these two genres. With this distinction you can better track genre popularity and improve your recommendations to match readers’ preferences. Since you already defined your Book class, you can have your new separate fiction and non-fiction classes inherit its properties.


- Create the class attributes `FICTION` and `NON_FICTION` in the `Book` class. The former should be set to 'Fiction' and the latter to 'Non Fiction'. These should be used to set the `genre` parameter when creating a `Book` object.
- There are two types of books: fiction and non-fiction books. Create the classes `FictionBook` and `NonFictionBook`. Both of them should inherit from the `Book` class.
- Implement the `__init__()` methods of the `FictionBook` and `NonFictionBook` classes. Both get as parameters the `title` (string), `author` (string), `rating` (float), `reviews` (integer), `price` (float), and `years` (list of integers) values for the instance attributes. When calling the constructor of the parent class, use the corresponding `Book` class attribute to set the `genre` value.
- Change the `__str__()` method in both classes. The method should return the title of the book along with the genre and the year(s) in which it was a bestseller. The string should follow the structure "`title`: `genre` (`year1`, `year2`, ..., `yearN`)".


### Task 3: Create Books from Dataset (25%)
Now you want to be able to give your dataset to a function and have the rest of the data processing go automatically. So you will need to create a method that will do this for you. This method will not only categorize books as fiction or non-fiction, but also ensure that books appearing in multiple years are brought together into a single entry, reflecting all their bestseller years. By automating this process, you can focus on analysing trends and make data-driven decisions for your bookstore.


- Create the method `read_books_csv()` in the `Amazon` class. 
The method takes a path to a file as input and returns nothing. 
The method should instead populate the `bestsellers` attribute with `Book` objects created from the dataset.
You should create either `FictionBook` or `NonFictionBook` objects, which will depend on the type of the book.
This time you must use the `csv` module to read the CSV file.
To open the file with the `open()` function, you need to set the `encoding` parameter to `'utf-8-sig'`.

*Additional remarks:*
- Transform the strings coming from the dataset into their corresponding type (e.g. integer).
- If the same book was a bestseller in two different years then it will appear twice in the csv. We want both entries to go to the same object to avoid duplicates, but add both years to the object. 
- Consider using a dictionary with the titles as keys and objects as values. This way you can access the object again and add another year. The result `bestsellers` will still be a list of Books.


### Task 4: Find the Year with the Most Popular and Enjoyable Books (15%)
The popularity of reading, the amount of books published and what genres do well change over time. By analyzing these trends, you'll gain insights into reader preferences and industry performance. Was there a year when exceptional quality captivated readers, or one where a surge of popular books sparked record-breaking reviews? By including methods to specifically investige the years with high ratings and high numbers of reviews, you will be able to uncover the standout years in publishing history. 


- Create the `best_year_rating()` method in the `Amazon` class.
The method has no parameters and returns an integer that represents the year with the best median rating. Consider using the `statistics` module to calculate the median value for each year.

- Create the `best_year_reviews()` method in the `Amazon` class.
The method has no parameters and returns an integer that represents the year with the best median reviews. Consider using the `statistics` module to calculate the median value for each year.


### Task 5: Recommend Books (25%)
Now that you have some insight into the industry in general, you want to get into what books you should consider for your inventory and what you should recommend to your customers. You already set up a way to extract all titles and information about the books. Now using the books you extracted, you want to create a list of recommendations based on the ratings and review counts. With this system, you can quickly identify the best of the best and be sure you are recommending books to your customers that they are likely to love. 


- Add the attribute `recommended` (Boolean) to the `Book` class and set it to `False`. Do not modify the list of parameters of the constructor.
- Create the method `recommend()` in the `Book` class. The method receives a rating and a number of reviews, and it does not return anything. If the (non)fiction book has a rating that is at least that of the first parameter and a number of reviews at least that of the second parameter, its `recommended` attribute must be set to `True`. 
- Create the method `recommend_book()`  in the `Amazon` class. The method receives a rating and a number of reviews. The method does not return anything. Instead, it iterates over the list of books and calls the corresponding `recommend()` method to recommend all books that fulfill the given requirements.
- Finally, create the method `get_recommendations()` in the `Amazon` class. The method has no parameters and returns a list of strings with the string representation (i.e. `str()`) of all recommended books (both fiction and non-fiction books).


