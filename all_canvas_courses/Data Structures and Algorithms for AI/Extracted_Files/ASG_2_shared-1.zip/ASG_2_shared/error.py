from typing import Union
import traceback


class ImportError(Exception):
    def __init__(self, lib: str):
        traceback_str = ''
        try:
            __import__(lib)
        except Exception:
            traceback_str = traceback.format_exc()

        super().__init__(f"Failed to import {lib}\n{traceback_str}")


class Timeout(Exception):
    def __init__(self, time_limit, exec_time):
        super().__init__(f"Execution took {round(exec_time, 4)}s, "
                         f"limit is {time_limit}s")


class NoOutput(Exception):
    def __init__(self):
        super().__init__("Function did not return anything. "
                         "Did you return your result?")


class WrongType(Exception):
    def __init__(self, type):
        super().__init__(f"Function returned wrong type. "
                         f"Expected type: {type}")


class WrongAnswer(Exception):
    def __init__(self, result: Union[int, bool],
                 answer: Union[int, bool]):
        super().__init__(f"Wrong answer, "
                         f"{result} != {answer}")
