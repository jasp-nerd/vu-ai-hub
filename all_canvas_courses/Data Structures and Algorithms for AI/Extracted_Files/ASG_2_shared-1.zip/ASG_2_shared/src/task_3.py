#!/usr/bin/env python3
'''
Std. no: XXXXXXX
'''

from typing import List, Union


def is_min_heap(array: List[int]
                ) -> Union[int, bool]:
    '''
    Determine if `array` represents a min heap

    ### Parameters
    `array`: An array of positive integers

    ### Return
    A boolean or int (0|1) for if the `array` is a min heap
    '''

    raise NotImplementedError
