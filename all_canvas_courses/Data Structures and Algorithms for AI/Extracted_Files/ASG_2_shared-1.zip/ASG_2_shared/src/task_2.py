#!/usr/bin/env python3
'''
Std. no: XXXXXXX
'''

from typing import List


def find_occurrences(array: List[int], n: int
                     ) -> int:
    '''
    Find the number of occurrences of `n` in the `array` list

    ### Parameters
    `array`: An  **ordered** array of positive integers

    `n`: int

    ### Return
    The number of occurrences of `n` in `array`
    '''

    raise NotImplementedError
