#!/usr/bin/env python3
'''
Std. no: XXXXXXX
'''

from typing import List, Tuple
stack = []


def find(__params__):
    '''
    TODO: Step 2: Implement the actual path finding find function.
        Add the parameters you need.
    '''

    raise NotImplementedError  # remove once implemented


def find_path(start_id: int, end_id: int, data: List[Tuple[int, List[int]]]
              ) -> List[int]:
    """
    TODO: Implement the find_path function.

    ### Parameters
    start_id : int
        ID of the starting node
    end_id : int
        ID of the target node
    data : list[tuple[int, list[int]]]
        List of tuples of the twitter user data (id:int, following:list[int])
            e.g. [(1, [2]), (2, [3]),(3, [4]), (4, [5]), (5,[])]

    ### Returns
    list[int]: List of the node id **as integers**
        of the path found between the start and end nodes
    """
    global stack
    stack = []

    for id, following in data:
        '''
        TODO: Step 1: Create and store the graph.
            The dataset gives you the IDs of the following.
            Meaning that in the above example:
                `1` is following `2`
                `2` is following `3`
                `3` is following `4`
                `4` is following `5`
                `5` is not following anyone.
            As such, the directed Graph's edges (links) will be:
                1->2, 2->3, 3->4, 4->5
            ! Pay attention to the case where a user is not following anyone.
        '''

        for f in following:
            raise NotImplementedError

    '''
    TODO: Step 3: Call your 'find` function with the parameters you defined.
    '''
    find(...)

    '''
    TODO: Step 4: return a list **of integers** of the node IDs.
        e.g. if the path requested before was 1 to 5 -> `[1,2,3,4,5]`
    '''
    raise NotImplementedError
