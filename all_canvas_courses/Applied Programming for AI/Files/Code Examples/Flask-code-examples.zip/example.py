import json

# Load JSON from file
with open('example.json', 'r') as f:
    data = json.load(f)

print("Loaded from JSON file:")
print(data)

# Equivalent Python dictionary
python_dict = {
    "name": "Alice",
    "age": 30,
    "is_student": False,
    "courses": ["Math", "Science"],
    "address": {
        "city": "Amsterdam",
        "zip": "1012AB"
    }
}

print("\nPython dictionary:")
print(python_dict)