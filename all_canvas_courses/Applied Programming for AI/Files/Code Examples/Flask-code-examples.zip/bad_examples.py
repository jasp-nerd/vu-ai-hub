from flask import Flask, request, jsonify

app = Flask(__name__)

# BAD: Using GET to delete data (should use DELETE)
@app.route('/bad_delete/<int:item_id>', methods=['GET'])
def bad_delete(item_id):
    # This is not RESTful: GET should never change server state!
    # Deleting with GET can lead to accidental data loss.
    return jsonify({"message": f"Item {item_id} deleted"}), 200

# BAD: Using POST to update data (should use PUT or PATCH)
@app.route('/bad_update/<int:item_id>', methods=['POST'])
def bad_update(item_id):
    # POST is for creating resources, not updating existing ones.
    # This can confuse clients and break REST conventions.
    data = request.get_json()
    return jsonify({"id": item_id, **data}), 200

# BAD: Returning plain strings instead of JSON
@app.route('/bad_response', methods=['GET'])
def bad_response():
    # REST APIs should return structured data (usually JSON), not plain text.
    return "This is not JSON!", 200

# BAD: Not using resource nouns in URLs
@app.route('/doSomething', methods=['POST'])
def do_something():
    # RESTful URLs should use nouns, not verbs.
    # E.g., use /items instead of /getItems
    return jsonify({"message": "Did something"}), 200

# BAD: Not handling errors or missing data
@app.route('/bad_error/<int:item_id>', methods=['GET'])
def bad_error(item_id):
    # No error handling if item does not exist
    # Should return 404 if not found
    return jsonify({"id": item_id, "name": "Example"})

if __name__ == '__main__':
    app.run(debug=True)