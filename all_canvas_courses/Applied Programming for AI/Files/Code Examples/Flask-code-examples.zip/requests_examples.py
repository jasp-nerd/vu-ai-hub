import requests

BASE_URL = "http://127.0.0.1:5000"

# Create a new item
new_item = {"name": "Book", "price": 12.99}
response = requests.post(f"{BASE_URL}/items", json=new_item)
print("POST /items:", response.status_code, response.json())

# Get all items
response = requests.get(f"{BASE_URL}/items")
print("GET /items:", response.status_code, response.json())

# Get a specific item (id=1)
response = requests.get(f"{BASE_URL}/items/1")
print("GET /items/1:", response.status_code, response.json())

# Update item with id=1
updated_item = {"name": "Book", "price": 10.99}
response = requests.put(f"{BASE_URL}/items/1", json=updated_item)
print("PUT /items/1:", response.status_code, response.json())

# Delete item with id=1
response = requests.delete(f"{BASE_URL}/items/1")
print("DELETE /items/1:", response.status_code)

# Try to get deleted item
response = requests.get(f"{BASE_URL}/items/1")
print("GET /items/1 after delete:", response.status_code, response.json())