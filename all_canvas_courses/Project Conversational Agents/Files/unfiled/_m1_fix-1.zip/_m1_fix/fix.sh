#!/bin/bash

# Save the starting directory
ORIGINAL_DIR=$(pwd)

# Check if we are already in _m1_fix; if not, create it and move into it
if [[ "$PWD" != *"_m1_fix" ]]; then
    echo "Moving into _m1_fix folder..."
    cd _m1_fix || exit
else
    echo "Already in _m1_fix folder."
fi

# install sound device
pip install sounddevice

cp -f  ./desktop_microphone.py ../social-interaction-cloud/sic_framework/devices/common_desktop/desktop_microphone.py
cp -f  ./desktop_speakers.py ../social-interaction-cloud/sic_framework/devices/common_desktop/desktop_speakers.py
cp -f  ./desktop_text_to_speech.py ../social-interaction-cloud/sic_framework/devices/common_desktop/desktop_text_to_speech.py

echo "Files overwritten successfully."

# Go back to the original directory
cd "$ORIGINAL_DIR"
echo "Returned to $ORIGINAL_DIR"