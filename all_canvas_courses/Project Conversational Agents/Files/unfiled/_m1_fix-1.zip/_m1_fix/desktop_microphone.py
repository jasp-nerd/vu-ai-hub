import numpy as np
import sounddevice as sd
from sic_framework import SICComponentManager
from sic_framework.core.connector import SICConnector
from sic_framework.core.message_python2 import AudioMessage, SICConfMessage
from sic_framework.core.sensor_python2 import SICSensor


class MicrophoneConf(SICConfMessage):
    def __init__(self):
        self.no_channels = 1
        self.sample_rate = 44100


class DesktopMicrophoneSensor(SICSensor):
    def __init__(self, *args, **kwargs):
        super(DesktopMicrophoneSensor, self).__init__(*args, **kwargs)

        self.audio_buffer = None

        # sounddevice doesn't need a top-level object like PyAudio()
        # We initialize a RawInputStream to get byte-data directly
        self.stream = sd.RawInputStream(
            samplerate=self.params.sample_rate,
            channels=1,
            dtype="int16",  # Equivalent to pyaudio.paInt16
        )
        self.stream.start()

    @staticmethod
    def get_conf():
        return MicrophoneConf()

    @staticmethod
    def get_inputs():
        return []

    @staticmethod
    def get_output():
        return AudioMessage

    def execute(self):
        self.logger.debug("Reading audio")

        # Calculate frames for 250ms chunks
        # $frames = \frac{sample\_rate}{4}$
        num_frames = int(self.params.sample_rate // 4)

        # sd.read returns a tuple (data, overflowed)
        data, overflowed = self.stream.read(num_frames)

        if overflowed:
            self.logger.warning("Audio input overflowed")

        return AudioMessage(bytes(data), sample_rate=self.params.sample_rate)

    def stop(self, *args):
        super(DesktopMicrophoneSensor, self).stop(*args)
        self.logger.info("Stopped microphone")
        self.stream.stop()
        self.stream.close()


class DesktopMicrophone(SICConnector):
    component_class = DesktopMicrophoneSensor


if __name__ == "__main__":
    SICComponentManager([DesktopMicrophoneSensor])
