import sounddevice as sd
from sic_framework import SICActuator, SICComponentManager
from sic_framework.core.connector import SICConnector
from sic_framework.core.message import SICMessage
from sic_framework.core.message_python2 import AudioMessage, SICConfMessage


class SpeakersConf(SICConfMessage):
    """
    Parameters for speakers go here.
    """

    def __init__(self, sample_rate=44100, channels=1):
        self.sample_rate = sample_rate
        self.channels = channels


class DesktopSpeakersActuator(SICActuator):
    def __init__(self, *args, **kwargs):
        super(DesktopSpeakersActuator, self).__init__(*args, **kwargs)

        # Initialize the output stream
        # Using RawOutputStream to accept byte-buffers directly
        self.stream = sd.RawOutputStream(
            samplerate=self.params.sample_rate,
            channels=self.params.channels,
            dtype="int16",  # Matches pyaudio.paInt16
        )
        self.stream.start()

    @staticmethod
    def get_conf():
        return SpeakersConf()

    @staticmethod
    def get_inputs():
        return [AudioMessage]

    @staticmethod
    def get_output():
        return SICMessage

    def on_request(self, request):
        # request.waveform is expected to be raw bytes
        self.stream.write(request.waveform)
        return SICMessage()

    def on_message(self, message):
        # Play the audio from the message
        self.stream.write(message.waveform)

    def stop(self, *args):
        super(DesktopSpeakersActuator, self).stop(*args)
        self.logger.info("Stopped speakers")

        self.stream.stop()
        self.stream.close()


class DesktopSpeakers(SICConnector):
    component_class = DesktopSpeakersActuator


if __name__ == "__main__":
    SICComponentManager([DesktopSpeakersActuator])
